_call_function(cbTools.getSmsNumber, {
    "changeData": (<%= changeData %>),
    "country": (<%= country %>),
    "operator": (<%= operator %>),
    "maxPrice": (<%= maxPrice %>),
    "areas": (<%= areas %>),
})!
<%= variable %> = _result_function()
