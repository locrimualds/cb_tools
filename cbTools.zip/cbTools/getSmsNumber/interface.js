<div class="container-fluid">
    <%= _.template($('#checkbox').html())({
        id:"changeData",
        title:"Использовать другую страну/оператора",
        checked: false,
        help: {
            description: "Получить номер определенной страны и опратора.",
            examples: [
                {
                    code: "Активировано",
                    description: "Указать другую страну/оператора"
                },
                {
                    code: "Деактивировано",
                    description: "Использовать страну/оператора из кубика 'Установить смс сервис'"
                }
            ]
        }
    }) %>
    <%= _.template($('#input_constructor').html())({
        id:"country",
        description:"Страна",
        visible_if_checked: "changeData",
        default_selector: "string",
        disable_int:true,
        value_string: "",
        help: {
            description: "Страна для получения номера"
        }
    }) %>
    <%= _.template($('#input_constructor').html())({
        id:"operator",
        description:"Оператор",
        visible_if_checked: "changeData",
        default_selector: "string",
        disable_int:true,
        value_string: "",
        help: {
            description: "Оператор для получения номера"
        }
    }) %>
    <%= _.template($('#block_start').html())({id:"Additional", name: tr("Additional settings"), description: ""}) %>
        <%= _.template($('#input_constructor').html())({
            id: "maxPrice",
            description: "Максимальная цена",
            default_selector: "string",
            value_number: "",
            help: {
                description: "Необязательный параметр. Работает не для всех сервисов.",
            }
        }) %>
        <%= _.template($('#input_constructor').html())({
            id: "areas",
            description: "Зоны",
            default_selector: "string",
            disable_int: true,
            value_number: "",
            help: {
                description: "Необязательный параметр. Работает только для сервиса DaisySMS. Указывать через запятую.",
            }
        }) %>
    <%= _.template($('#block_end').html())() %>
    <%= _.template($('#variable_constructor').html())({
        id:"Save",
        description:"Результат",
        default_variable: "SMS_NUMBER",
        help: {
            description: "Возвращает полученный номер телефона."
        }
    }) %>
</div>
<div class="tooltipinternal">
    <div class="tooltip-paragraph-first-fold">Получить номер смс сервиса.</div>
</div>
<%= _.template($('#back').html())({action: "executeandadd", visible: true}) %>
