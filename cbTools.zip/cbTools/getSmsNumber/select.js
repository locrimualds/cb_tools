var changeData = $("#changeData").is(':checked');

var country = GetInputConstructorValue("country", loader);
var operator = GetInputConstructorValue("operator", loader);

if (changeData && country["original"].length == 0) {
    Invalid("Поле Страна" + " пустое");
    return;
}

if (changeData && operator["original"].length == 0) {
    Invalid("Поле Оператор" + " пустое");
    return;
}

var maxPrice = GetInputConstructorValue("maxPrice", loader);
var areas = GetInputConstructorValue("areas", loader);

var Save = this.$el.find("#Save").val().toUpperCase();
try {
    var code = loader.GetAdditionalData() + _.template($("#cbTools_getSmsNumber_code").html())({
        "changeData": changeData,
        "country": country["updated"],
        "operator": operator["updated"],
        "maxPrice": maxPrice["updated"],
        "areas": areas["updated"],
        "variable": "VAR_" + Save
    });
    code = Normalize(code, 0);
    BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
} catch (e) {
    log(e);
}
