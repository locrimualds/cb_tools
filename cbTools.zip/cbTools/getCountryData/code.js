_call_function(cbTools.getCountryData, {
    "country": (<%= country %>),
})!
<%= variable %> = _result_function()
