var country = GetInputConstructorValue("country", loader);
if (country["original"].length == 0) {
    Invalid("Поле Страна" + " пустое");
    return;
}

var Save = this.$el.find("#Save").val().toUpperCase();
try {
    var code = loader.GetAdditionalData() + _.template($("#cbTools_getCountryData_code").html())({
        "country": country["updated"],
        "variable": "VAR_" + Save
    });
    code = Normalize(code, 0);
    BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
} catch (e) {
    log(e);
}
