<div class="container-fluid">
    <%= _.template($('#input_constructor').html())({
        id:"country",
        description:"Страна",
        default_selector: "string",
        disable_int:true,
        value_string: "",
        help: {
            description: "Название страны."
        }
    }) %>
    <%= _.template($('#variable_constructor').html())({
        id:"Save",
        description:"Результат",
        default_variable: "COUNTRY_DATA",
        help: {
            description: "Возвращает объект данных страны."
        }
    }) %>
</div>
<div class="tooltipinternal">
    <div class="tooltip-paragraph-first-fold">Получить данные страны - код, префикс номера и т.д.</div>
</div>
<%= _.template($('#back').html())({action: "executeandadd", visible: true}) %>
