var phoneNumber = GetInputConstructorValue("phoneNumber", loader);
if (phoneNumber["original"].length == 0) {
    Invalid("Поле Номер телефона" + " пустое");
    return;
}

try {
    var code = loader.GetAdditionalData() + _.template($("#cbTools_updateSmsNumber_code").html())({
        "phoneNumber": phoneNumber["updated"],
    });
    code = Normalize(code, 0);
    BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
} catch (e) {
    log(e);
}
