<div class="container-fluid">
    <%= _.template($('#input_constructor').html())({id:"phoneNumber", description:"Объект с номером телефона", default_selector: "expression", disable_int:true, disable_string:true, value_string: "", help: {description: "Объект с номером телефона"} }) %>
</div>
<div class="tooltipinternal">
    <div class="tooltip-paragraph-first-fold">Запросить повторный код на номер.</div>
</div>
<%= _.template($('#back').html())({action: "executeandadd", visible: true}) %>
