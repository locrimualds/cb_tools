_call_function(cbTools.updateSmsNumber, {
    "phoneNumber": (<%= phoneNumber %>),
})!
