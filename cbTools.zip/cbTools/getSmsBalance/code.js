_call_function(cbTools.getSmsBalance, {

})!
<%= variable %> = _result_function()
