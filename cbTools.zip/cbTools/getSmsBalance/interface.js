<div class="container-fluid">
    <%= _.template($('#variable_constructor').html())({id:"Save", description:"Результат", default_variable: "SMS_BALANCE", help: {description: "Возвращает текущий баланс."}}) %>
</div>
<div class="tooltipinternal">
    <div class="tooltip-paragraph-first-fold">Получить баланс смс сервиса.</div>
</div>
<%= _.template($('#back').html())({action: "executeandadd", visible: true}) %>
