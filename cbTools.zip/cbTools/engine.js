cbTools = {
    smsService: null,

    checkSmsService: function() {
        if (!cbTools.smsService)
            fail("Не установлен смс сервис");
    },

    inputText: function() {
        var inputElement = _function_argument("inputElement").replace(/"/g, "'")
        inputElement = inputElement.charAt(0) === '/' ? "document.evaluate(\"" + inputElement + "\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue" : inputElement
        const text = _function_argument("text")
        page().script2("function inputText(element, text) {" +
            "    element.setAttribute('value', text);" +
            "    var event = new Event('input', { bubbles: true });" +
            "    element.dispatchEvent(event);" +
            "    event.stopPropagation();" +
            "}" +
            "inputText(" + inputElement + ", \"" + text + "\");", JSON.stringify(_read_variables([])))!
        var _parse_result = JSON.parse(_result())
        _write_variables(JSON.parse(_parse_result.variables))
        if(!_parse_result.is_success)
            fail(_parse_result.error)
    },

    getCountryData: function() {
        const country = _function_argument("country").trim().toLowerCase();
        const countries = Object.keys(cbTools.countries).reduce(function(acc, key) {
            acc[key.toLowerCase()] = cbTools.countries[key];
            return acc;
        }, {});

        if (Object.keys(countries).indexOf(country) === -1)
            _function_return(false)

        _function_return(countries[country])
    },

    setSmsService: function() {
        var service = _function_argument("service").trim();
        const apiKey = _function_argument("apiKey").trim();
        const country = _function_argument("country").trim();
        var operator = _function_argument("operator").trim();
        operator = operator === "Любой" ? "any" : operator

        if (Object.keys(cbTools.sms.serviceList).indexOf(service) === -1)
            fail("Неизвестный смс сервис");

        service = cbTools.sms.serviceList[service];

        cbTools.sms[service].apiKey = apiKey;
        _call_function(cbTools.sms[service].testConnect, null)!
        const result = _result_function();
        if (result.error)
            fail(result.data);

        _call_function(cbTools.sms[service].getCountries, null)!
        const countries = _result_function();

        if (countries.hasOwnProperty("error"))
            fail(countries.data);

        if (countries.indexOf(country) === -1)
            fail("Неизвестная страна \"" + country + "\" для сервиса " + cbTools.sms[service].name);

        _call_function(cbTools.sms[service].getCountryId, {country: country})!
        const countryID = _result_function();

        cbTools.sms[service].country = countryID;
        cbTools.sms[service].countryName = country;
        cbTools.sms[service].operator = operator;

        cbTools.smsService = cbTools.sms[service];
    },

    getSmsBalance: function() {
        cbTools.checkSmsService();

        _call_function(cbTools.smsService.getBalance, null)!
        const result = _result_function()

        if (result.error)
            fail(result.data);

        const balance = {
            source: result.data,
            formatted: cbTools.smsService.getBalanceFormated(result.data),
            low: result.data <= cbTools.smsService.minBalance,
        }

        _function_return(balance)
    },

    getSmsNumber: function() {
        cbTools.checkSmsService();

        const changeData = _function_argument("changeData");
        const country = _function_argument("country").trim();
        var operator = _function_argument("operator").trim();
        var countryId = "";

        _if (changeData, function () {
            _call_function(cbTools.smsService.getCountries, null)!
            const countries = _result_function();

            if (countries.indexOf(country) === -1)
                fail("Неизвестная страна \"" + country + "\" для сервиса " + cbTools.smsService.name);

            operator = operator === "Любой" ? "any" : operator

            _call_function(cbTools.smsService.getCountryId, {country: country})!
            countryId = _result_function();
        })!

        countryId = changeData ? countryId : cbTools.smsService.country;
        const countryName = changeData ? country : cbTools.smsService.countryName;
        operator = changeData ? operator : cbTools.smsService.operator;

        _call_function(cbTools.smsService.getNumber, {country: countryId, countryName: countryName, operator: operator})!
        const result = _result_function()

        if (result.error)
            fail(result.data)

        _function_return(result.data)
    },

    getSmsCode: function() {
        cbTools.checkSmsService();

        const phoneNumber = _function_argument("phoneNumber");
        const time = _function_argument("time");
        const doClose = _function_argument("doClose");
        const doCloseIfCodeFalse = _function_argument("doCloseIfCodeFalse");

        const startTime = Date.now();

        _do(function () {
            const elapsedTime = (Date.now() - startTime) / 1000;
            _call_function(cbTools.smsService.getCode, {phoneNumber: phoneNumber})!
            const result = _result_function()

            if (result.error) {
                fail(result.data)
            }

            _if (result.data !== false, function () {
                _if (doClose, function () {
                    _call_function(cbTools.smsService.completeNumber, {phoneNumber: phoneNumber})!
                })!

                _function_return(result.data.replace(/[^0-9]/gim,''))
            })!

            _if (elapsedTime >= time, function () {
                _if (doCloseIfCodeFalse, function () {
                    _call_function(cbTools.smsService.cancelNumber, {phoneNumber: phoneNumber})!
                })!

                _function_return(false)
            })!

            sleep(3000)!
        })!

        _function_return(false)
    },

    updateSmsNumber: function() {
        cbTools.checkSmsService();

        const phoneNumber = _function_argument("phoneNumber");
        _call_function(cbTools.smsService.updateNumber, {phoneNumber: phoneNumber})!
        const result = _result_function()

        if (result.error)
            fail(result.data)
    },
}