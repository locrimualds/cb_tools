var phoneNumber = GetInputConstructorValue("phoneNumber", loader);
if (phoneNumber["original"].length == 0) {
    Invalid("Поле Номер телефона" + " пустое");
    return;
}

var time = GetInputConstructorValue("time", loader);
if (time["original"].length == 0) {
    Invalid("Поле Время ожидания" + " пустое");
    return;
}

var doClose = $("#doClose").is(':checked');
var doCloseIfCodeFalse = $("#doCloseIfCodeFalse").is(':checked');

var Save = this.$el.find("#Save").val().toUpperCase();
try {
    var code = loader.GetAdditionalData() + _.template($("#cbTools_getSmsCode_code").html())({
        "phoneNumber": phoneNumber["updated"],
        "time": time["updated"],
        "doClose": doClose,
        "doCloseIfCodeFalse": doCloseIfCodeFalse,
        "variable": "VAR_" + Save
    });
    code = Normalize(code, 0);
    BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
} catch (e) {
    log(e);
}
