_call_function(cbTools.getSmsCode, {
    "phoneNumber": (<%= phoneNumber %>),
    "time": (<%= time %>),
    "doClose": (<%= doClose %>),
    "doCloseIfCodeFalse": (<%= doCloseIfCodeFalse %>),
})!
<%= variable %> = _result_function()
