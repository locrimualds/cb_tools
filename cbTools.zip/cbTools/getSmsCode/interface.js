<div class="container-fluid">
    <%= _.template($('#input_constructor').html())({id:"phoneNumber", description:"Объект с номером телефона", default_selector: "expression", disable_int:true, disable_string:true, value_string: "", help: {description: "Объект с номером телефона"} }) %>
    <%= _.template($('#input_constructor').html())({id:"time", description:"Время ожидания", default_selector: "int", disable_string:true, value_number: 120, help: {description: "Время ожидания смс кода"} }) %>
    <%= _.template($('#checkbox').html())({id:"doClose", title:"Закрыть номер после получения кода", checked: false, help: {description: "Закрыть номер после получения кода.", examples: [{code: "Активировано", description: "Номер будет закрыт, после получения кода"}, {code: "Деактивировано", description: "После получения кода, номер останется доступен"}]} }) %>
    <%= _.template($('#checkbox').html())({id:"doCloseIfCodeFalse", title:"Закрыть номер, если код не поступил", checked: false, help: {description: "Закрыть номер, если код не поступил в течении указанного времени.", examples: [{code: "Активировано", description: "Номер будет закрыт, после неудачного ожидания кода"}, {code: "Деактивировано", description: "После неудачного ожидания кода, номер останется доступен"}]} }) %>
    <%= _.template($('#variable_constructor').html())({id:"Save", description:"Результат", default_variable: "SMS_CODE", help: {description: "Возвращает полученный код."}}) %>
</div>
<div class="tooltipinternal">
    <div class="tooltip-paragraph-first-fold">Получить смс код.</div>
</div>
<%= _.template($('#back').html())({action: "executeandadd", visible: true}) %>
