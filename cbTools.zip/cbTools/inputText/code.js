_call_function(cbTools.inputText,{
    "inputElement": (<%= inputElement %>),
    "text": (<%= text %>),
})!
