_call_function(cbTools.inputText,{
    "inputElement": (<%= inputElement %>),
    "text": (<%= text %>),
    "doClick": (<%= doClick %>),
    "clickDelay": (<%= clickDelay %>),
    "clickElement": (<%= clickElement %>),
})!
