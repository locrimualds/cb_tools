<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"inputElement", description:"Input селектор", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "Xpath <br><code>//*[contains(@type, 'email')]</code><br><br>CSS <br><code>document.queySelector('input')</code>"}}) %>
<%= _.template($('#input_constructor').html())({id:"text", description:"Текст", default_selector: "string", disable_int:true, value_string: "", help: {description: "Текст для ввода."} }) %>
</div>
<div class="tooltipinternal">
    <div class="tooltip-paragraph-first-fold">Ввести текст в input по Xpath или CSS.</div>
</div>
<%= _.template($('#back').html())({action: "executeandadd", visible: true}) %>
