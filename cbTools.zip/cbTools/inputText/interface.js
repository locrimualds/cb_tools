<div class="container-fluid">
    <%= _.template($('#input_constructor').html())({id:"inputElement", description:"Input селектор", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "Xpath <br><code>//*[contains(@type, 'email')]</code><br><br>CSS <br><code>document.querySelector('input')</code>"}}) %>
    <%= _.template($('#input_constructor').html())({id:"text", description:"Текст", default_selector: "string", disable_int:true, value_string: "", help: {description: "Текст для ввода."} }) %>
    <%= _.template($('#checkbox').html())({id:"doClick", title:"Кликнуть по элементу", checked: false, help: {description: "Кликнуть по указанному элементу после ввода текста."} }) %>
    <%= _.template($('#input_constructor').html())({id:"clickDelay", description:"Задержка клика", visible_if_checked: "doClick", default_selector: "int", disable_expression:true, disable_string:true, min_number: 1, value_number: 500, help: {description: "Задержка перед нажатием на указанный элемент"}}) %>
    <%= _.template($('#input_constructor').html())({id:"clickElement", description:"Click селектор", visible_if_checked: "doClick", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "Xpath <br><code>//*[contains(@type, 'email')]</code><br><br>CSS <br><code>document.querySelector('input')</code>"}}) %>
</div>
<div class="tooltipinternal">
    <div class="tooltip-paragraph-first-fold">Ввести текст в input по Xpath или CSS.</div>
</div>
<%= _.template($('#back').html())({action: "executeandadd", visible: true}) %>
