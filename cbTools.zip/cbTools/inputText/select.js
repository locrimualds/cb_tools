var inputElement = GetInputConstructorValue("inputElement", loader);
if (inputElement["original"].length == 0) {
    Invalid("Поле Input селектор" + " пустое");
    return;
}

var text = GetInputConstructorValue("text", loader);
if (text["original"].length == 0) {
    Invalid("Поле Текст" + " пустое");
    return;
}

try {
    var code = loader.GetAdditionalData() + _.template($("#cbTools_inputText_code").html())({
        "inputElement": inputElement["updated"],
        "text": text["updated"],
    });
    code = Normalize(code, 0);
    BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
} catch (e) {
    log(e);
}
