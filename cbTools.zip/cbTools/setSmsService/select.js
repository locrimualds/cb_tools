var service = GetInputConstructorValue("service", loader);
if (service["original"].length == 0) {
    Invalid("Поле Смс сервис" + " пустое");
    return;
}

var apiKey = GetInputConstructorValue("apiKey", loader);
if (apiKey["original"].length == 0) {
    Invalid("Поле API ключ" + " пустое");
    return;
}

var country = GetInputConstructorValue("country", loader);
if (country["original"].length == 0) {
    Invalid("Поле Страна" + " пустое");
    return;
}

var operator = GetInputConstructorValue("operator", loader);
if (operator["original"].length == 0) {
    Invalid("Поле Оператор" + " пустое");
    return;
}

try {
    var code = loader.GetAdditionalData() + _.template($("#cbTools_setSmsService_code").html())({
        "service": service["updated"],
        "apiKey": apiKey["updated"],
        "country": country["updated"],
        "operator": operator["updated"],
    });
    code = Normalize(code, 0);
    BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
} catch (e) {
    log(e);
}
