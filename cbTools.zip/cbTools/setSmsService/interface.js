<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"service", description:"Смс сервис", default_selector: "string", disable_int:true, value_string: "", help: {description: "Код смс сервиса."}}) %>
<%= _.template($('#input_constructor').html())({id:"apiKey", description:"API ключ", default_selector: "string", disable_int:true, value_string: "", help: {description: "Ключ к API сервиса."}}) %>
<%= _.template($('#input_constructor').html())({id:"country", description:"Страна", default_selector: "string", disable_int:true, value_string: "", help: {description: "Страна."}}) %>
<%= _.template($('#input_constructor').html())({id:"operator", description:"Оператор", default_selector: "string", disable_int:true, value_string: "", help: {description: "Оператор."}}) %>
</div>
<div class="tooltipinternal">
    <div class="tooltip-paragraph-first-fold">Установить смс сервис для дальнейшей работы.</div>
    <div class="tooltip-paragraph-last-fold">
        Доступные сервисы:
        <ul>
            <li><b>Smshub</b></li>
            <li><b>Sms-activate</b></li>
            <li><b>Simsms</b></li>
            <li><b>Sms2max</b></li>
        </ul>
    </div>
</div>
<%= _.template($('#back').html())({action: "executeandadd", visible: true}) %>
