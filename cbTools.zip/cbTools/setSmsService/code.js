_call_function(cbTools.setSmsService, {
    "service": (<%= service %>),
    "apiKey": (<%= apiKey %>),
    "country": (<%= country %>),
    "operator": (<%= operator %>),
})!
