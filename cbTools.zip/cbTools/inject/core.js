cbTools.sms = {
    serviceList: {
        "Smshub": "smshub",
        "Sms-activate": "smsActivate",
        "Simsms": "simsms",
        "Sms2max": "smsTwoMax",
        "Vaksms": "vaksms",
        "DaisySMS": "daisysms",
    },
}

cbTools.request = {
    get: function() {
        const url = _function_argument("url");

        _call(function() {
            _on_fail(function() {
                VAR_LAST_ERROR = _result()
                VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                VAR_WAS_ERROR = false
                _break(1, true)
            });
            CYCLES.Current().RemoveLabel("function");

            _switch_http_client_main();
            http_client_get_no_redirect2(url, {
                "method": ("GET"),
                headers: ("")
            })!
        },null)!

        _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function() {
            fail(VAR_LAST_ERROR);
        })!

        _switch_http_client_main();
        if (http_client_status() !== 200) {
            _function_return("SERVER_UNAVAILABLE");
        }

        _function_return(http_client_encoded_content("auto"));
    },

    isError: function (errors, data) {
        return Object.keys(errors).indexOf(data) !== -1;
    },

    returnFormat: function (error, data) {
        return {error: error, data: data};
    }
}

cbTools.startsWith = function(str, search, pos) {
    pos = pos || 0;
    return str.substr(pos, search.length) === search;
}
