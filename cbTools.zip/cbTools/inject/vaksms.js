cbTools.sms.vaksms = {
    name: "Vak-SMS",
    baseApiUrl: "https://vak-sms.com/api/",
    apiKey: "",
    serviceCode: "cb",
    country: "",
    countryName: "",
    operator: "",
    currency: "₽",
    minBalance: 100,
    errorServerResponses: {
        "apiKeyNotFound": "Неверный API ключ.",
        "noService": "Данный сервис не поддерживается, свяжитесь с администрацией сайта.",
        "noNumber": "Нет номеров, попробуйте позже.",
        "noMoney" : "Недостаточно средств, пополните баланс.",
        "noCountry": "Запрашиваемая страна отсутствует.",
        "noOperator": "Оператор не найден для запрашиваемой страны.",
        "badStatus": "Не верный статус.",
        "idNumNotFound": "Не верный ID операции.",
        "badService": "Не верный код сайта, сервиса, соц. сети.",
        "badData": "Отправлены неверные данные.",
        "updateNumberError": "Ошибка обновления номера.",
    },

    testConnect: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.vaksms.getApiURL("getBalance")})!
        const response = _result_function();
        _function_return(cbTools.sms.vaksms.returnResult(response));
    },

    getBalance: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.vaksms.getApiURL("getBalance")})!
        const response = _result_function();
        _function_return(cbTools.sms.vaksms.returnResult(response, "balance"));
    },

    getBalanceFormated: function(value) {
        return _number_format(value, 0, "", ".", " ") + this.currency;
    },

    getNumber: function() {
        const country = _function_argument("country");
        const countryName = _function_argument("countryName");
        var operator = _function_argument("operator");

        if (operator === "any") operator = "";

        _call_function(cbTools.request.get, {url: cbTools.sms.vaksms.getApiURL("getNumber", {service: cbTools.sms.vaksms.serviceCode, country: country, operator: operator})})!
        const response = _result_function();
        const result = cbTools.sms.vaksms.returnResult(response, {id: "idNum", number: "tel"});

        if (!result.error && cbTools.countries.hasOwnProperty(countryName)) {
            result.data.number = result.data.number.toString().slice(cbTools.countries[countryName].prefix.length);
        }

        _function_return(result);
    },

    getCode: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.vaksms.getApiURL("getSmsCode", {idNum: phoneNumber.id})})!
        var response = _result_function();
        response = JSON.parse(response);

        if (response.smsCode === null)
            _function_return(cbTools.sms.vaksms.returnResult(response, null, false));

        _function_return(cbTools.sms.vaksms.returnResult(response, "smsCode"));
    },

    cancelNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.vaksms.getApiURL("setStatus", {status: "end", idNum: phoneNumber.id})})!
    },

    completeNumber: function() {

    },

    updateNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.vaksms.getApiURL("setStatus", {status: "send", idNum: phoneNumber.id})})!
        var response = _result_function();
        response = JSON.parse(response);

        if (response.status !== "ready")
            _function_return(cbTools.sms.vaksms.returnResult({error: "updateNumberError"}));

        _function_return(cbTools.sms.vaksms.returnResult(response, null, true));
    },

    getApiURL: function (path, params) {
        var urlParams = [];

        if (params !== undefined) {
            for (var key in params) {
                if (Object.prototype.hasOwnProperty.call(params, key)) {
                    urlParams[urlParams.length] = encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
                }
            }
        }

        urlParams = urlParams ? "&" + urlParams.join('&') : "";
        return this.baseApiUrl + path + "/?apiKey=" + this.apiKey + urlParams;
    },

    returnResult: function(result, keys, returnData) {
        try {
            if (typeof result === 'string')
                result = JSON.parse(result);
        }
        catch (e) {
            return cbTools.request.returnFormat(true, result);
        }

        if (result.hasOwnProperty("error")) {
            return cbTools.request.returnFormat(true, cbTools.sms.vaksms.errorServerResponses[result.error])
        }

        if (returnData !== undefined)
            return cbTools.request.returnFormat(false, returnData)

        if (!keys)
            return cbTools.request.returnFormat(false, result);

        if (typeof keys !== "object")
            return cbTools.request.returnFormat(false, result[keys]);

        const data = {};
        for (var key in keys) {
            data[key] = result[keys[key]];
        }

        return cbTools.request.returnFormat(false, data);
    },

    getCountries: function () {
        _function_return(cbTools.sms.vaksms.data.map(function(data) {return data.countryName}));
    },

    getOperators: function() {
        _function_return(cbTools.sms.vaksms.data);
    },

    getCountryId: function() {
        const country = _function_argument("country");
        var result = null;

        for (var i = 0; i < cbTools.sms.vaksms.data.length; i++) {
            if (cbTools.sms.vaksms.data[i].countryName === country) {
                result = cbTools.sms.vaksms.data[i];
                break;
            }
        }
        _function_return(result.countryCode);
    },

    data: [
        {"countryName": "Таджикистан", "countryCode": "tj", "operatorList": ["babilon mobile", "beeline", "megafon", "tcell"]},
        {"countryName": "Зимбабве", "countryCode": "zw", "operatorList": ["econet", "netone", "telecel"]},
        {"countryName": "Азербайджан", "countryCode": "az", "operatorList": ["azercell", "bakcell", "nar mobile", "naxtel", "azerfon", "humans"]},
        {"countryName": "Танзания", "countryCode": "tz", "operatorList": ["vodacom"]},
        {"countryName": "США (виртуальная)", "countryCode": "usv", "operatorList": ["textnow"]},
        {"countryName": "Гватемала", "countryCode": "gt", "operatorList": ["claro", "movistar", "tigo"]},
        {"countryName": "Словакия", "countryCode": "sk", "operatorList": ["4ka", "o2", "orange", "telekom"]},
        {"countryName": "Египет", "countryCode": "eg", "operatorList": ["etisalat", "orange", "vodafone", "we"]},
        {"countryName": "Кипр", "countryCode": "cy", "operatorList": ["epic", "lemontel", "primetel", "vodafon", "cablenet"]},
        {"countryName": "Косово", "countryCode": "xk", "operatorList": ["ipko", "mtc", "vala"]},
        {"countryName": "Малави", "countryCode": "mw", "operatorList": ["access", "airtel", "tnm"]},
        {"countryName": "Тимор-Лешти", "countryCode": "tl", "operatorList": ["telemor", "telkomcel", "timor telecom"]},
        {"countryName": "Шри-Ланка", "countryCode": "lk", "operatorList": ["airtel", "dialog", "etisalat", "hutch", "lanka bell", "mobitel", "slt"]},
        {"countryName": "Мьянма", "countryCode": "mm", "operatorList": ["mytel", "mpt", "ooredoo", "telenor"]},
        {"countryName": "Оман", "countryCode": "om", "operatorList": ["ooredoo", "omantel"]},
        {"countryName": "Хорватия", "countryCode": "hr", "operatorList": ["a1", "bonbon", "hrvatski telekom", "telemach"]},
        {"countryName": "Пакистан", "countryCode": "pk", "operatorList": ["charji", "jazz", "sco mobile", "telenor", "ufone", "zong"]},
        {"countryName": "Перу", "countryCode": "pe", "operatorList": ["bitel", "claro", "entel", "movistar"]},
        {"countryName": "Палестина", "countryCode": "ps", "operatorList": ["jawwal", "wataniya"]},
        {"countryName": "Кыргызстан", "countryCode": "kg", "operatorList": ["megacom", "o!", "beeline", "nurtel"]},
        {"countryName": "Ниуэ", "countryCode": "nu", "operatorList": ["telecom"]},
        {"countryName": "Австралия", "countryCode": "au", "operatorList": ["vodafone", "telstra"]},
        {"countryName": "Греция", "countryCode": "gr", "operatorList": ["cosmote", "cyta", "vodafone", "wind"]},
        {"countryName": "Сьерра-Леоне", "countryCode": "sl", "operatorList": ["orange", "africell", "sierratel"]},
        {"countryName": "Израиль", "countryCode": "il", "operatorList": ["golan telecom", "018 xphone", "rami levy", "partner", "cellcom", "pelephone", "hot mobile", "azi", "pali"]},
        {"countryName": "Узбекистан", "countryCode": "uz", "operatorList": ["beeline", "perfectum", "ucell", "ums", "uzmobile"]},
        {"countryName": "Аргентина", "countryCode": "ar", "operatorList": ["claro", "movistar", "nextel", "personal"]},
        {"countryName": "Австрия", "countryCode": "at", "operatorList": ["a1", "lycamobile", "orange", "telering"]},
        {"countryName": "Бангладеш", "countryCode": "bd", "operatorList": ["airtel", "banglalink", "grameenphone", "ollo", "robi", "teletalk", "banglalion"]},
        {"countryName": "Чехия", "countryCode": "cz", "operatorList": ["vodafone", "tmobile", "szdc", "o2", "nordic telecom"]},
        {"countryName": "Южноафриканская Республика", "countryCode": "za", "operatorList": ["cell c", "mtn", "neotel", "telkom", "vodacom"]},
        {"countryName": "Ангола", "countryCode": "ao", "operatorList": ["movicel"]},
        {"countryName": "Канада (виртуальная)", "countryCode": "cav", "operatorList": ["textnow"]},
        {"countryName": "Словения", "countryCode": "si", "operatorList": ["a1", "t-2", "telekom", "telemach"]},
        {"countryName": "Украина", "countryCode": "ua", "operatorList": ["vodafone", "kyivstar", "lifecell", "lycamobile"]},
        {"countryName": "США", "countryCode": "us", "operatorList": ["tmobile"]},
        {"countryName": "Мозамбик", "countryCode": "mz", "operatorList": ["mcell", "movitel", "vodacom"]},
        {"countryName": "Вьетнам", "countryCode": "vn", "operatorList": ["vietnamobile", "viettel", "vinaphone"]},
        {"countryName": "Испания", "countryCode": "es", "operatorList": ["yoigo", "lycamobile", "vodafone", "movistar", "orange"]},
        {"countryName": "Нидерланды", "countryCode": "nl", "operatorList": ["lebara", "lycamobile", "lmobiel", "kpn", "vodafone"]},
        {"countryName": "Дания", "countryCode": "dk", "operatorList": ["lycamobile", "three", "tdc", "telenor", "telia"]},
        {"countryName": "Эстония", "countryCode": "ee", "operatorList": ["telia", "tele2", "elisa"]},
        {"countryName": "Великобритания", "countryCode": "gb", "operatorList": ["vodafone", "three", "tmobile", "o2", "ee", "lycamobile", "orange", "giffgaff"]},
        {"countryName": "Казахстан", "countryCode": "kz", "operatorList": ["tele2", "beeline", "altel", "activ", "forte mobile"]},
        {"countryName": "Румыния", "countryCode": "ro", "operatorList": ["vodafone", "lycamobile", "orange"]},
        {"countryName": "Болгария", "countryCode": "bg", "operatorList": ["a1", "bulsatcom", "max telecom", "telenor", "vivacom"]},
        {"countryName": "Мексика", "countryCode": "mx", "operatorList": ["telcel", "movistar"]},
        {"countryName": "Гонконг", "countryCode": "hk", "operatorList": ["three", "smartone", "csl", "china mobile", "pccw"]},
        {"countryName": "Индонезия", "countryCode": "id", "operatorList": ["axis", "telkomsel", "three", "indosat", "smartfren"]},
        {"countryName": "Латвия", "countryCode": "lv", "operatorList": ["tele2", "lmt", "pylduk", "zelta zivtina"]},
        {"countryName": "Польша", "countryCode": "pl", "operatorList": ["orange", "tmobile", "plus", "play", "nju"]},
        {"countryName": "Лаос", "countryCode": "la", "operatorList": ["etl", "laotel", "unitel", "beeline"]},
        {"countryName": "Филиппины", "countryCode": "ph", "operatorList": ["globe telecom", "smart", "sun cellular"]},
        {"countryName": "Грузия", "countryCode": "ge", "operatorList": ["beeline", "geocell", "magticom", "silknet"]},
        {"countryName": "Франция", "countryCode": "fr", "operatorList": ["lycamobile", "lebara", "sfr", "symamobile", "orange", "bouygues"]},
        {"countryName": "Россия", "countryCode": "ru", "operatorList": ["tele2", "rostelecom", "mts", "megafon", "beeline", "lycamobile", "mtt", "yota", "tinkoff", "vtbmobile", "patriot", "vector", "win mobile", "sbermobile"]},
        {"countryName": "Финляндия", "countryCode": "fi", "operatorList": ["elisa", "dna"]},
        {"countryName": "Германия", "countryCode": "de", "operatorList": ["lycamobile", "vodafone", "lebara"]},
        {"countryName": "Литва", "countryCode": "lt", "operatorList": ["tele2", "labas", "pylduk"]},
        {"countryName": "Кения", "countryCode": "ke", "operatorList": ["airtel", "econet", "orange", "safaricom", "telkom"]},
        {"countryName": "Таиланд", "countryCode": "th", "operatorList": ["dtac", "ais", "truemove"]},
        {"countryName": "Малайзия", "countryCode": "my", "operatorList": ["indosat", "celcom", "digi", "electcoms", "maxis", "telekom", "tune talk", "yes", "u mobile", "xox"]},
        {"countryName": "Молдова", "countryCode": "md", "operatorList": ["moldcell", "orange"]},
        {"countryName": "Марокко", "countryCode": "ma", "operatorList": ["inwi", "orange", "maroc telecom"]},
        {"countryName": "Португалия", "countryCode": "pt", "operatorList": ["vodafone", "lycamobile"]},
        {"countryName": "Швеция", "countryCode": "se", "operatorList": ["telenor", "lycamobile", "comviq"]}
    ]
}
