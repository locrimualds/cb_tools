cbTools.sms.simsms = {
    name: "SimSMS",
    baseApiUrl: "https://simsms.org/priemnik.php",
    apiKey: "",
    serviceCode: "opt112",
    country: "",
    countryName: "",
    operator: "",
    currency: "₽",
    minBalance: 100,
    errorServerResponses: {
        "SERVER_UNAVAILABLE": "Сервер недоступен",
        "Произошла неизвестная ошибка.": "Сервер недоступен",
        "Произошла внутренняя ошибка сервера.": "Сервер недоступен",
        "Превышено количество попыток!" : "Превышено количество попыток!",
        "API KEY не получен!": "Неверный API ключ",
        "API KEY не найден!": "Неверный API ключ",
        "API KEY ВРЕМЕННО ЗАБЛОКИРОВАН": "API ключ временно заблокирован",
        "Неверный запрос.": "Неверный запрос",
        "Недостаточно средств!": "Недостаточно средств на балансе",
        "NO_NUMBERS": "Нет доступных номеров",
        "UPDATE_NUMBER_ERROR": "Ошибка обновления номера",
    },

    testConnect: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.simsms.getApiURL({metod: "get_balance"})})!
        const response = _result_function();
        _function_return(cbTools.sms.simsms.returnResult(response));
    },

    getBalance: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.simsms.getApiURL({metod: "get_balance"})})!
        const response = _result_function();
        _function_return(cbTools.sms.simsms.returnResult(response, "balance"));
    },

    getBalanceFormated: function(value) {
        return _number_format(value, 0, "", ".", " ") + this.currency;
    },

    getNumber: function() {
        const country = _function_argument("country");

        _call_function(cbTools.request.get, {url: cbTools.sms.simsms.getApiURL({metod: "get_number", service: cbTools.sms.simsms.serviceCode, country: country})})!
        const response = _result_function();
        if (response.indexOf('"id":-1') !== -1) {
            _function_return(cbTools.sms.simsms.returnResult("NO_NUMBERS"));
        }
        _function_return(cbTools.sms.simsms.returnResult(response, {id: "id", number: "number", country: "country"}));
    },

    getCode: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.simsms.getApiURL({metod: "get_sms", service: cbTools.sms.simsms.serviceCode, country: phoneNumber.country, id: phoneNumber.id, sms: "sms"})})!
        const response = _result_function();
        if (response.indexOf('"sms":null') !== -1)
            _function_return(cbTools.sms.simsms.returnResult(response, null, false));

        _function_return(cbTools.sms.simsms.returnResult(response, "sms"));
    },

    cancelNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.simsms.getApiURL({metod: "denial", service: cbTools.sms.simsms.serviceCode, country: phoneNumber.country, id: phoneNumber.id})})!
    },

    completeNumber: function() {

    },

    updateNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.simsms.getApiURL({metod: "get_clearsms", service: cbTools.sms.simsms.serviceCode, id: phoneNumber.id})})!
        const response = _result_function();
        if (response.indexOf('"clearsms":"non_ok"') !== -1)
            _function_return(cbTools.sms.simsms.returnResult("UPDATE_NUMBER_ERROR"));

        _function_return(cbTools.sms.simsms.returnResult(response, null, true));
    },

    getApiURL: function (params) {
        var urlParams = [];
        for (var key in params) {
            if (Object.prototype.hasOwnProperty.call(params, key)) {
                urlParams[urlParams.length] = encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
            }
        }
        urlParams = urlParams.join('&');
        return this.baseApiUrl + "?apikey=" + this.apiKey + "&" + urlParams;
    },

    returnResult: function(result, keys, returnData) {
        try {
            result = JSON.parse(result);
        }
        catch (e) {
            return cbTools.request.returnFormat(true, cbTools.sms.simsms.errorServerResponses[result])
        }

        if (result.response === "error") {
            return cbTools.request.returnFormat(true, result.error_msg)
        }

        if (returnData !== undefined)
            return cbTools.request.returnFormat(false, returnData)

        if (!keys)
            return cbTools.request.returnFormat(false, result);

        if (typeof keys !== "object")
            return cbTools.request.returnFormat(false, result[keys]);

        const data = {};
        for (var key in keys) {
            data[key] = result[keys[key]];
        }

        return cbTools.request.returnFormat(false, data);
    },

    getCountries: function () {
        _function_return(Object.keys(cbTools.sms.simsms.data.countries));
    },

    getOperators: function() {
        _function_return(cbTools.sms.simsms.data.operators);
    },

    getCountryId: function() {
        const country = _function_argument("country");
        _function_return(cbTools.sms.simsms.data.countries[country]);
    },

    data: {
        countries: {
            "Россия": "RU",
            "Канада": "CA",
            "США": "US",
            "Франция": "FR",
            "Англия": "UK",
            "Германия": "DE",
            "Италия": "IT",
            "Австралия": "AU",
            "Австрия": "AT",
            "Албания": "AL",
            "Аргентина": "AR",
            "Бангладеш": "BD",
            "Болгария": "BG",
            "Бос. и Герц.": "BA",
            "Бразилия": "BR",
            "Венгрия": "HU",
            "Вьетнам": "VN",
            "Гибралтар": "GI",
            "Гонконг": "HK",
            "Греция": "GR",
            "Грузия": "GE",
            "Дания": "DK",
            "Доминикана": "DO",
            "Египет": "EG",
            "Израиль": "IL",
            "Индия": "IN",
            "Индонезия": "ID",
            "Камбоджа": "KH",
            "Кипр": "CY",
            "Колумбия": "CO",
            "Мексика": "MX",
            "Хорватия": "HR",
            "Чехия": "CZ",
            "Ирландия": "IE",
            "Испания": "ES",
            "Казахстан": "KZ",
            "Камерун": "CM",
            "Кения": "KE",
            "Киргизия (Virtual)": "KG",
            "Лаос": "LA",
            "Латвия": "LV",
            "Литва": "LT",
            "Македония": "MK",
            "Малайзия": "MY",
            "Мальта": "MT",
            "Марокко": "MA",
            "Молдова": "MD",
            "Нигерия": "NG",
            "Нидерланды": "NL",
            "Новая Зеландия": "NZ",
            "Норвегия": "NO",
            "Пакистан (Virtual)": "PK",
            "Парагвай": "PY",
            "Польша": "PL",
            "Португалия": "PT",
            "Румыния": "RO",
            "Саудовская Аравия": "SA",
            "Сербия": "RS",
            "Сингапур": "SG",
            "Словакия": "SK",
            "Словения": "SI",
            "Таиланд": "TH",
            "Танзания": "TZ",
            "Турция": "TR",
            "Узбекистан (Virtual)": "UZ",
            "Украина": "UA",
            "Филиппины": "PH",
            "Финляндия": "FI",
            "Чили": "CL",
            "Швейцария": "CH",
            "Швеция": "SE",
            "Эстония": "EE",
            "ЮАР": "ZA",
            "Япония": "JP"
        },
        operators: [
            "any",
            "Plus_Pl",
            "Lyca_PL",
            "TMobile_PL",
            "Orange_PL",
            "Play_PL",
            "LycaMobile_PL",
            "A2Mobile_PL",
            "symamobile_FR",
            "SFR_FR",
            "Lebara_FR",
            "LycaMobile_FR",
            "Lebara2_FR",
            "Telia_EE",
            "Elisa_EE",
            "Tele2_EE",
            "KPN_NL",
            "Lyca_NL",
            "TMobile_NL",
            "Lebara_NL",
            "LMOBIEL_NL",
        ]
    }
}
