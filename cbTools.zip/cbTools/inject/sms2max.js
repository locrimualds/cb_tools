cbTools.sms.smsTwoMax = {
    name: "Sms2Max",
    baseApiUrl: "https://sms2max.com/stubs/handler_api.php",
    apiKey: "",
    serviceCode: "re",
    country: "",
    countryName: "",
    operator: "",
    currency: "$",
    minBalance: 1,
    errorServerResponses: {
        "SERVER_UNAVAILABLE": "Сервер недоступен",
        "BAD_KEY": "Неверный API ключ",
        "API_KEY_NOT_VALID": "Неверный API ключ",
        "NO_NUMBERS": "Нет доступных номеров",
        "NO_BALANCE": "Недостаточно денег на балансе",
        "WRONG_SERVICE": "Неверный код сервиса Coinbase",
        "STATUS_CANCEL": "Номер закрыт",
        "NO_ACTIVATION": "Номер телефона не найден",
        "BAD_STATUS": "Невозможно обновить статус номера"
    },

    testConnect: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.smsTwoMax.getApiURL({action: "getBalance"})})!
        const response = _result_function();
        _function_return(cbTools.sms.smsTwoMax.returnResult(response, null, true));
    },

    getBalance: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.smsTwoMax.getApiURL({action: "getBalance"})})!
        const response = _result_function();
        _function_return(cbTools.sms.smsTwoMax.returnResult(response, 1));
    },

    getBalanceFormated: function(value) {
        return _number_format(value, 2, "", ".", " ") + this.currency;
    },

    getNumber: function() {
        const country = _function_argument("country");
        const countryName = _function_argument("countryName");
        const operator = _function_argument("operator");

        _call_function(cbTools.request.get, {url: cbTools.sms.smsTwoMax.getApiURL({action: "getNumber", service: cbTools.sms.smsTwoMax.serviceCode, country: country, operator: operator})})!
        const response = _result_function();
        const result = cbTools.sms.smsTwoMax.returnResult(response, {id: 1, number: 2});

        if (!result.error && cbTools.countries.hasOwnProperty(countryName)) {
            result.data.number = result.data.number.slice(cbTools.countries[countryName].prefix.length);
        }

        _function_return(result);
    },

    getCode: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.smsTwoMax.getApiURL({action: "getStatus", id: phoneNumber.id})})!
        const response = _result_function();
        if (response.indexOf("STATUS_WAIT") !== -1)
            _function_return(cbTools.sms.smsTwoMax.returnResult(response, null, false));

        _function_return(cbTools.sms.smsTwoMax.returnResult(response, 1));
    },

    cancelNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.smsTwoMax.getApiURL({action: "setStatus", status: 8, id: phoneNumber.id})})!
    },

    completeNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.smsTwoMax.getApiURL({action: "setStatus", status: 6, id: phoneNumber.id})})!
    },

    updateNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.smsTwoMax.getApiURL({action: "setStatus", status: 3, id: phoneNumber.id})})!
        const response = _result_function();
        _function_return(cbTools.sms.smsTwoMax.returnResult(response, response));
    },

    getApiURL: function (params) {
        var urlParams = [];
        for (var key in params) {
            if (Object.prototype.hasOwnProperty.call(params, key)) {
                urlParams[urlParams.length] = encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
            }
        }
        urlParams = urlParams.join('&');
        return this.baseApiUrl + "?api_key=" + this.apiKey + "&" + urlParams;
    },

    returnResult: function(result, reformatData, returnData) {
        if (cbTools.request.isError(cbTools.sms.smsTwoMax.errorServerResponses, result))
            return cbTools.request.returnFormat(true, cbTools.sms.smsTwoMax.errorServerResponses[result])

        if (returnData !== undefined)
            return cbTools.request.returnFormat(false, returnData);

        if (reformatData === null || reformatData === undefined)
            return cbTools.request.returnFormat(false, result);

        result = result.split(":");

        if (typeof reformatData === "number")
            return cbTools.request.returnFormat(false, result[reformatData]);

        for (var key in reformatData) {
            reformatData[key] = result[reformatData[key]]
        }

        return cbTools.request.returnFormat(false, reformatData);
    },

    getCountries: function () {
        _function_return(Object.keys(cbTools.sms.smsTwoMax.data.countries));
    },

    getOperators: function() {
        _function_return(cbTools.sms.smsTwoMax.data.operators);
    },

    getCountryId: function() {
        const country = _function_argument("country");
        _function_return(cbTools.sms.smsTwoMax.data.countries[country]);
    },

    data: {
        countries: {
            "Украина": "1",
            "Казахстан": "2",
            "Китай": "3",
            "Филиппины": "4",
            "Мьянма (Бирма)": "5",
            "Индонезия": "6",
            "Малайзия": "7",
            "Кения": "8",
            "Танзания": "9",
            "Вьетнам": "10",
            "Киргизия": "11",
            "Израиль": "13",
            "Гонконг (САР Китай)": "14",
            "Польша": "15",
            "Англия": "16",
            "Мадагаскар": "17",
            "Нигерия": "19",
            "Макао (САР Китай)": "20",
            "Египет": "21",
            "Индия": "22",
            "Ирландия": "23",
            "Камбоджа": "24",
            "Лаос": "25",
            "Гаити": "26",
            "Кот-д’Ивуар": "27",
            "Гамбия": "28",
            "Сербия": "29",
            "Йемен": "30",
            "Южная Африка": "31",
            "Румыния": "32",
            "Колумбия": "33",
            "Эстония": "34",
            "Азербайджан": "35",
            "Канада": "36",
            "Марокко": "37",
            "Гана": "38",
            "Аргентина": "39",
            "Узбекистан": "40",
            "Камерун": "41",
            "Чад": "42",
            "Германия": "43",
            "Литва": "44",
            "Хорватия": "45",
            "Швеция": "46",
            "Ирак": "47",
            "Нидерланды": "48",
            "Латвия": "49",
            "Австрия": "50",
            "Беларусь": "51",
            "Таиланд": "52",
            "Саудовская Аравия": "53",
            "Мексика": "54",
            "Тайвань": "55",
            "Испания": "56",
            "Иран": "57",
            "Алжир": "58",
            "Словения": "59",
            "Бангладеш": "60",
            "Сенегал": "61",
            "Турция": "62",
            "Чехия": "63",
            "Шри-Ланка": "64",
            "Перу": "65",
            "Пакистан": "66",
            "Новая Зеландия": "67",
            "Гвинея": "68",
            "Мали": "69",
            "Венесуэла": "70",
            "Эфиопия": "71",
            "Монголия": "72",
            "Бразилия": "73",
            "Афганистан": "74",
            "Уганда": "75",
            "Ангола": "76",
            "Кипр": "77",
            "Франция": "78",
            "Папуа — Новая Гвинея": "79",
            "Мозамбик": "80",
            "Непал": "81",
            "Бельгия": "82",
            "Болгария": "83",
            "Венгрия": "84",
            "Молдова": "85",
            "Италия": "86",
            "Парагвай": "87",
            "Гондурас": "88",
            "Тунис": "89",
            "Никарагуа": "90",
            "Восточный Тимор": "91",
            "Боливия": "92",
            "Коста-Рика": "93",
            "Гватемала": "94",
            "Объединенные Арабские Эмираты": "95",
            "Зимбабве": "96",
            "Пуэрто-Рико": "97",
            "Судан": "98",
            "Того": "99",
            "Кувейт": "100",
            "Сальвадор": "101",
            "Ливия": "102",
            "Ямайка": "103",
            "Тринидад и Тобаго": "104",
            "Эквадор": "105",
            "Оман": "107",
            "Босния и Герцеговина": "108",
            "Доминиканская Республика": "109",
            "Сирия": "110",
            "Катар": "111",
            "Панама": "112",
            "Куба": "113",
            "Мавритания": "114",
            "Сьерра-Леоне": "115",
            "Иордания": "116",
            "Португалия": "117",
            "Барбадос": "118",
            "Бурунди": "119",
            "Бенин": "120",
            "Бруней": "121",
            "Багамы": "122",
            "Ботсвана": "123",
            "Белиз": "124",
            "Доминика": "126",
            "Гренада": "127",
            "Грузия": "128",
            "Греция": "129",
            "Гвинея-Бисау": "130",
            "Гайана": "131",
            "Исландия": "132",
            "Коморы": "133",
            "Сент-Китс и Невис": "134",
            "Либерия": "135",
            "Лесото": "136",
            "Малави": "137",
            "Намибия": "138",
            "Нигер": "139",
            "Руанда": "140",
            "Словакия": "141",
            "Суринам": "142",
            "Таджикистан": "143",
            "Монако": "144",
            "Бахрейн": "145",
            "Реюньон": "146",
            "Замбия": "147",
            "Армения": "148",
            "Сомали": "149",
            "Конго-Браззавиль": "150",
            "Чили": "151",
            "Буркина-Фасо": "152",
            "Ливан": "153",
            "Габон": "154",
            "Албания": "155",
            "Уругвай": "156",
            "Маврикий": "157",
            "Бутан": "158",
            "Мальдивы": "159",
            "Гваделупа": "160",
            "Туркменистан": "161",
            "Французская Гвиана": "162",
            "Финляндия": "163",
            "Сент-Люсия": "164",
            "Люксембург": "165",
            "Сент-Винсент и Гренадины": "166",
            "Экваториальная Гвинея": "167",
            "Джибути": "168",
            "Антигуа и Барбуда": "169",
            "Каймановы острова": "170",
            "Черногория": "171",
            "Дания": "172",
            "Швейцария": "173",
            "Норвегия": "174",
            "Австралия": "175",
            "Эритрея": "176",
            "Южный Судан": "177",
            "Сан-Томе и Принсипи": "178",
            "Аруба": "179",
            "Монтсеррат": "180",
            "Ангилья": "181",
            "Северная Македония": "183",
            "Сейшельские Острова": "184",
            "Новая Каледония": "185",
            "Кабо-Верде": "186",
            "США": "187",
            "Фиджи": "189",
            "Сингапур": "196",
            "Гибралтар": "201"
        },
        operators: [
            "any",
            "Lycamobile",
        ],
    }
}
