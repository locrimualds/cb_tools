cbTools.sms.smshub = {
    name: "SmsHub",
    baseApiUrl: "https://smshub.org/stubs/handler_api.php",
    apiKey: "",
    serviceCode: "re",
    country: "",
    countryName: "",
    operator: "",
    currency: "$",
    minBalance: 1,
    errorServerResponses: {
        "SERVER_UNAVAILABLE": "Сервер недоступен",
        "BAD_KEY": "Неверный API ключ",
        "API_KEY_NOT_VALID": "Неверный API ключ",
        "NO_NUMBERS": "Нет доступных номеров",
        "NO_BALANCE": "Недостаточно денег на балансе",
        "WRONG_SERVICE": "Неверный код сервиса Coinbase",
        "STATUS_CANCEL": "Номер закрыт",
        "NO_ACTIVATION": "Номер телефона не найден",
        "BAD_STATUS": "Невозможно обновить статус номера"
    },

    testConnect: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.smshub.getApiURL({action: "getBalance"})})!
        const response = _result_function();
        _function_return(cbTools.sms.smshub.returnResult(response, null, true));
    },

    getBalance: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.smshub.getApiURL({action: "getBalance"})})!
        const response = _result_function();
        _function_return(cbTools.sms.smshub.returnResult(response, 1));
    },

    getBalanceFormated: function(value) {
        return _number_format(value, 2, "", ".", " ") + this.currency;
    },

    getNumber: function() {
        const country = _function_argument("country");
        const countryName = _function_argument("countryName");
        const operator = _function_argument("operator");

        _call_function(cbTools.request.get, {url: cbTools.sms.smshub.getApiURL({action: "getNumber", service: cbTools.sms.smshub.serviceCode, country: country, operator: operator})})!
        const response = _result_function();
        const result = cbTools.sms.smshub.returnResult(response, {id: 1, number: 2});

        if (!result.error && cbTools.countries.hasOwnProperty(countryName)) {
            result.data.number = result.data.number.slice(cbTools.countries[countryName].prefix.length);
        }

        _function_return(result);
    },

    getCode: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.smshub.getApiURL({action: "getStatus", id: phoneNumber.id})})!
        const response = _result_function();
        if (response.indexOf("STATUS_WAIT") !== -1)
            _function_return(cbTools.sms.smshub.returnResult(response, null, false));

        _function_return(cbTools.sms.smshub.returnResult(response, 1));
    },

    cancelNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.smshub.getApiURL({action: "setStatus", status: 8, id: phoneNumber.id})})!
    },

    completeNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.smshub.getApiURL({action: "setStatus", status: 6, id: phoneNumber.id})})!
    },

    updateNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.smshub.getApiURL({action: "setStatus", status: 3, id: phoneNumber.id})})!
        const response = _result_function();
        _function_return(cbTools.sms.smshub.returnResult(response, response));
    },

    getApiURL: function (params) {
        var urlParams = [];
        for (var key in params) {
            if (Object.prototype.hasOwnProperty.call(params, key)) {
                urlParams[urlParams.length] = encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
            }
        }
        urlParams = urlParams.join('&');
        return this.baseApiUrl + "?api_key=" + this.apiKey + "&" + urlParams;
    },

    returnResult: function(result, reformatData, returnData) {
        if (cbTools.request.isError(cbTools.sms.smshub.errorServerResponses, result))
            return cbTools.request.returnFormat(true, cbTools.sms.smshub.errorServerResponses[result])

        if (returnData !== undefined)
            return cbTools.request.returnFormat(false, returnData);

        if (reformatData === null || reformatData === undefined)
            return cbTools.request.returnFormat(false, result);

        result = result.split(":");

        if (typeof reformatData === "number")
            return cbTools.request.returnFormat(false, result[reformatData]);

        for (var key in reformatData) {
            reformatData[key] = result[reformatData[key]]
        }

        return cbTools.request.returnFormat(false, reformatData);
    },

    getCountries: function () {
        _function_return(Object.keys(cbTools.sms.smshub.data));
    },

    getOperators: function() {
        const country = _function_argument("country");
        _function_return(cbTools.sms.smshub.data[country].operators);
    },

    getCountryId: function() {
        const country = _function_argument("country");
        _function_return(cbTools.sms.smshub.data[country].id);
    },

    data: {
        "Россия": {
            id: 0,
            operators: ["aiva", "any", "beeline", "center2m", "danycom", "ezmobile", "gazprombank_mobile", "lycamobile", "matrix", "mcn", "megafon", "motiv", "mts", "mtt", "mtt_virtual", "rostelecom", "sber", "simsim", "tele2", "tinkoff", "ttk", "vtb_mobile", "winmobile", "yota"]
        },
        "Украина": {
            id: 1,
            operators: ["3mob", "any", "intertelecom", "kyivstar", "life", "lycamobile", "mts", "utel", "vodafone"]
        },
        "Казахстан": {
            id: 2,
            operators: ["activ", "altel", "any", "beeline", "forte_mobile", "kcell", "tele2"]
        },
        "Китай": {
            id: 3,
            operators: ["any", "chinamobile", "china_unicom", "unicom"]
        },
        "Филиппины": {
            id: 4,
            operators: ["any", "globe_telecom", "smart", "tm"]
        },
        "Мьянма": {
            id: 5,
            operators: ["any", "mpt", "mytel", "ooredoo", "telenor"]
        },
        "Индонезия": {
            id: 6,
            operators: ["any", "axis", "indosat", "smartfren", "telkomsel", "three"]
        },
        "Малайзия": {
            id: 7,
            operators: ["any", "celcom", "digi", "hotlink", "tune_talk", "unifi", "u_mobile", "xox", "yes"]
        },
        "Кения": {
            id: 8,
            operators: ["airtel", "any", "econet", "orange", "safaricom", "telkom"]
        },
        "Танзания": {
            id: 9,
            operators: ["airtel", "any", "halotel", "tigo", "ttcl", "vodacom"]
        },
        "Вьетнам": {
            id: 10,
            operators: ["any", "itelecom", "mobifone", "vietnamobile", "viettel", "vinaphone", "wintel"]
        },
        "Кыргызстан": {
            id: 11,
            operators: ["any", "beeline", "megacom", "o!"]
        },
        "Израиль": {
            id: 13,
            operators: ["019mobile", "any", "golan_telecom", "home_cellular", "hot_mobile", "jawwal", "ooredoo", "orange", "pelephone", "rami_levy"]
        },
        "Гонконг": {
            id: 14,
            operators: ["any", "chinamobile", "csl_mobile", "imc", "lucky_sim", "smartone", "three", "unicom"]
        },
        "Польша": {
            id: 15,
            operators: ["a2_mobile", "aero2", "any", "e_telko", "heyah", "klucz", "lycamobile", "netia", "nju", "orange", "play", "plus", "plush", "red_bull_mobile", "tmobile", "virgin"]
        },
        "Англия": {
            id: 16,
            operators: ["airtel", "any", "cmlink", "ee", "ezmobile", "giffgaff", "lebara", "lycamobile", "o2", "orange", "talk_telecom", "tata_communications", "teleena", "three", "tmobile", "vectone", "vodafone"]
        },
        "Мадагаскар": {
            id: 17,
            operators: ["any", "orange"]
        },
        "Демократическая Республика Конго": {
            id: 18,
            operators: ["africel", "airtel", "any", "orange", "vodacom"]
        },
        "Нигерия": {
            id: 19,
            operators: ["airtel", "any", "etisalat", "glomobile", "mtn"]
        },
        "Макао": {
            id: 20,
            operators: ["3macao", "any"]
        },
        "Египет": {
            id: 21,
            operators: ["any", "etisalat", "orange", "vodafone"]
        },
        "Индия": {
            id: 22,
            operators: ["airtel", "any"]
        },
        "Ирландия": {
            id: 23,
            operators: ["48mobile", "any", "cablenet", "eir", "lycamobile", "tesco", "vodafone"]
        },
        "Камбоджа": {
            id: 24,
            operators: ["any", "metfone", "smart"]
        },
        "Лаос": {
            id: 25,
            operators: ["any", "etl", "telekom", "tplus", "unitel"]
        },
        "Гаити": {
            id: 26,
            operators: ["any", "natcom"]
        },
        "Кот-д'Ивуар": {
            id: 27,
            operators: ["any", "moov", "mtn", "orange"]
        },
        "Гамбия": {
            id: 28,
            operators: ["africel", "any", "comium", "gamcel", "qcell"]
        },
        "Сербия": {
            id: 29,
            operators: ["a1", "any", "mobtel", "mts", "vip"]
        },
        "Йемен": {
            id: 30,
            operators: ["any", "mtn", "sabafon", "yemen_mobile"]
        },
        "Южноафриканская Республика": {
            id: 31,
            operators: ["any", "cell_c", "lycamobile", "mtn", "telkom", "vodacom"]
        },
        "Румыния": {
            id: 32,
            operators: ["any", "benefito_mobile", "digi", "lycamobile", "my_avon", "orange", "runex_telecom", "telekom", "vodafone"]
        },
        "Колумбия": {
            id: 33,
            operators: ["any", "claro", "etb", "exito", "movistar", "tigo", "virgin", "wom"]
        },
        "Эстония": {
            id: 34,
            operators: ["any", "elisa", "goodline", "super", "tele2", "topconnect"]
        },
        "Азербайджан": {
            id: 35,
            operators: ["any", "azercell", "azerfon", "humans"]
        },
        "Канада": {
            id: 36,
            operators: ["any", "cellular", "chatrmobile", "fido", "lucky", "rogers", "telus"]
        },
        "Марокко": {
            id: 37,
            operators: ["any", "iam", "inwi", "itissalat", "orange"]
        },
        "Гана": {
            id: 38,
            operators: ["airtel", "any", "glomobile", "millicom", "mtn", "vodafone"]
        },
        "Аргентина": {
            id: 39,
            operators: ["any", "claro", "movistar", "personal", "tuenti"]
        },
        "Узбекистан": {
            id: 40,
            operators: ["any", "beeline", "humans", "mobiuz", "mts", "ucell", "uzmobile"]
        },
        "Камерун": {
            id: 41,
            operators: ["any", "mtn", "nexttel", "orange"]
        },
        "Чад": {
            id: 42,
            operators: ["airtel", "any", "salam", "tigo"]
        },
        "Германия": {
            id: 43,
            operators: ["any", "fonic", "lebara", "lycamobile", "o2", "ortel_mobile", "telekom", "vodafone"]
        },
        "Литва": {
            id: 44,
            operators: ["any", "bite", "tele2", "telia"]
        },
        "Хорватия": {
            id: 45,
            operators: ["a1", "any", "bonbon", "tele2", "telemach", "tmobile", "tomato"]
        },
        "Швеция": {
            id: 46,
            operators: ["any", "comviq", "lycamobile", "netmore", "tele2", "telenor", "telia", "three", "vectone", "vodafone"]
        },
        "Ирак": {
            id: 47,
            operators: ["any", "asiacell", "korek", "zain"]
        },
        "Нидерланды": {
            id: 48,
            operators: ["any", "kpn", "lebara", "lycamobile", "l_mobi", "tmobile", "vodafone"]
        },
        "Латвия": {
            id: 49,
            operators: ["any", "bite", "lmt", "tele2", "xomobile"]
        },
        "Австрия": {
            id: 50,
            operators: ["a1", "any", "eety", "hot_mobile", "lidl", "lycamobile", "magenta", "orange", "telering", "three", "tmobile", "wowww", "yesss"]
        },
        "Беларусь": {
            id: 51,
            operators: ["any", "best", "life", "mdc", "mts"]
        },
        "Таиланд": {
            id: 52,
            operators: ["ais", "any", "cat_mobile", "dtac", "my", "truemove"]
        },
        "Саудовская Аравия": {
            id: 53,
            operators: ["any"]
        },
        "Мексика": {
            id: 54,
            operators: ["any", "telcel"]
        },
        "Тайвань": {
            id: 55,
            operators: ["any", "chunghwa", "fareast"]
        },
        "Испания": {
            id: 56,
            operators: ["altecom", "any", "cube_movil", "euskaltel", "finetwork", "lebara", "lycamobile", "masmovil", "movistar", "orange", "tmobile", "vodafone", "yoigo", "you_mobile"]
        },
        "Иран": {
            id: 57,
            operators: ["any", "aptel", "azartel", "hamrah_e_aval", "irancell", "mtn", "rightel", "samantel", "shatel", "taliya", "tci"]
        },
        "Алжир": {
            id: 58,
            operators: ["any", "djezzy", "mobilis", "ooredoo"]
        },
        "Словения": {
            id: 59,
            operators: ["a1", "any", "telekom", "telemach"]
        },
        "Бангладеш": {
            id: 60,
            operators: ["any"]
        },
        "Сенегал": {
            id: 61,
            operators: ["any", "expresso", "free", "orange"]
        },
        "Турция": {
            id: 62,
            operators: ["any", "turkcell", "turk_telekom", "vodafone"]
        },
        "Чехия": {
            id: 63,
            operators: ["any", "kaktus", "o2", "tmobile", "vodafone"]
        },
        "Шри-Ланка": {
            id: 64,
            operators: ["airtel", "any", "dialog", "etisalat", "hutch", "sltmobitel"]
        },
        "Перу": {
            id: 65,
            operators: ["any", "movistar"]
        },
        "Пакистан": {
            id: 66,
            operators: ["any", "jazz", "ptcl", "sco", "telenor", "ufone", "zong"]
        },
        "Новая Зеландия": {
            id: 67,
            operators: ["2degree", "any", "one_nz", "skinny", "spark", "vodafone", "warehouse"]
        },
        "Гвинея": {
            id: 68,
            operators: ["any", "cellcom", "mtn", "orange", "sotelgui", "telecel"]
        },
        "Мали": {
            id: 69,
            operators: ["any", "malitel", "orange", "telecel"]
        },
        "Венесуэла": {
            id: 70,
            operators: ["any"]
        },
        "Эфиопия": {
            id: 71,
            operators: ["any", "mtn", "safaricom"]
        },
        "Монголия": {
            id: 72,
            operators: ["any", "beeline"]
        },
        "Бразилия": {
            id: 73,
            operators: ["algartelecom", "any", "arqia", "cellular", "claro", "correios_celular", "nlt", "oi", "tim", "vivo"]
        },
        "Афганистан": {
            id: 74,
            operators: ["any", "salaam"]
        },
        "Уганда": {
            id: 75,
            operators: ["airtel", "any", "k2_telecom", "lycamobile", "mtn", "orange", "smart", "smile", "uganda_telecom"]
        },
        "Ангула": {
            id: 76,
            operators: ["africel", "any", "unitel"]
        },
        "Кипр": {
            id: 77,
            operators: ["any", "cablenet", "cyta", "epic", "lemontel", "primetel", "vectone", "vodafone"]
        },
        "Франция": {
            id: 78,
            operators: ["any", "bouygues", "free", "kena_mobile", "lebara", "lycamobile", "orange", "sfr", "syma_mobile", "vectone"]
        },
        "Папуа": {
            id: 79,
            operators: ["any"]
        },
        "Мозамбик": {
            id: 80,
            operators: ["any", "tmcel", "vodacom"]
        },
        "Непал": {
            id: 81,
            operators: ["any"]
        },
        "Бельгия": {
            id: 82,
            operators: ["any", "bandwidth", "base", "infrabel", "lycamobile", "nethys", "orange", "proximus", "vectone"]
        },
        "Болгария": {
            id: 83,
            operators: ["a1", "any", "telenor", "vivacom", "yettel"]
        },
        "Венгрия": {
            id: 84,
            operators: ["any", "tmobile", "vodafone", "yettel"]
        },
        "Молдова": {
            id: 85,
            operators: ["any", "idc", "moldcell", "orange", "unite"]
        },
        "Италия": {
            id: 86,
            operators: ["any", "digi", "ho", "iliad", "kena_mobile", "lycamobile", "nt_mobile", "optima", "syma_mobile", "tim", "vodafone", "wind"]
        },
        "Парагвай": {
            id: 87,
            operators: ["any", "claro", "personal"]
        },
        "Гондурас": {
            id: 88,
            operators: ["any", "claro"]
        },
        "Тунис": {
            id: 89,
            operators: ["any", "ooredoo", "orange", "tunicell"]
        },
        "Никарагуа": {
            id: 90,
            operators: ["any", "movistar"]
        },
        "Восточный Тимор": {
            id: 91,
            operators: ["any", "telemor", "telkomcel", "timor_telecom"]
        },
        "Боливия": {
            id: 92,
            operators: ["any", "tigo", "viva"]
        },
        "Коста-Рика": {
            id: 93,
            operators: ["any"]
        },
        "Гренада": {
            id: 94,
            operators: ["any", "claro", "movistar", "tigo"]
        },
        "ОАЭ": {
            id: 95,
            operators: ["any", "du"]
        },
        "Зимбабве": {
            id: 96,
            operators: ["any", "econet"]
        },
        "Пуэрто-Рико": {
            id: 97,
            operators: ["any"]
        },
        "Судан": {
            id: 98,
            operators: ["any", "mtn", "sudani_one", "zain"]
        },
        "Того": {
            id: 99,
            operators: ["any", "moov"]
        },
        "Кувейт": {
            id: 100,
            operators: ["any"]
        },
        "Сальвадор": {
            id: 101,
            operators: ["any", "claro", "digi", "movistar", "red", "tigo"]
        },
        "Ливия": {
            id: 102,
            operators: ["any"]
        },
        "Ямайка": {
            id: 103,
            operators: ["any", "digi"]
        },
        "Тринидад": {
            id: 104,
            operators: ["any"]
        },
        "Эквадор": {
            id: 105,
            operators: ["any", "claro", "cnt_mobile", "movistar", "tuenti"]
        },
        "Свазиленд": {
            id: 106,
            operators: ["any"]
        },
        "Оман": {
            id: 107,
            operators: ["any"]
        },
        "Босния": {
            id: 108,
            operators: ["a1", "any", "hej"]
        },
        "Доминиканская Республика": {
            id: 109,
            operators: ["altice", "any", "claro", "viva"]
        },
        "Сирия": {
            id: 110,
            operators: ["any", "mtn"]
        },
        "Катар": {
            id: 111,
            operators: ["any"]
        },
        "Панама": {
            id: 112,
            operators: ["any"]
        },
        "Куба": {
            id: 113,
            operators: ["any", "cubacel"]
        },
        "Мавритания": {
            id: 114,
            operators: ["any", "chinguitel", "mattel", "mauritel"]
        },
        "Сьерра-Леоне": {
            id: 115,
            operators: ["africel", "airtel", "any", "qcell"]
        },
        "Иордания": {
            id: 116,
            operators: ["any", "orange", "umniah", "xpress", "zain"]
        },
        "Португалия": {
            id: 117,
            operators: ["any", "lebara", "lycamobile", "nos", "vodafone"]
        },
        "Барбадос": {
            id: 118,
            operators: ["any"]
        },
        "Бурунди": {
            id: 119,
            operators: ["africel", "any", "econet", "lacell", "telecel", "viettel"]
        },
        "Бенин": {
            id: 120,
            operators: ["airtel", "any", "mtn"]
        },
        "Бруней": {
            id: 121,
            operators: ["any"]
        },
        "Багамы": {
            id: 122,
            operators: ["any"]
        },
        "Ботсвана": {
            id: 123,
            operators: ["any", "be_mobile", "mascom", "orange"]
        },
        "Белиз": {
            id: 124,
            operators: ["any"]
        },
        "Центральноафриканская Республика": {
            id: 125,
            operators: ["any"]
        },
        "Доминика": {
            id: 126,
            operators: ["any"]
        },
        "Гренада": {
            id: 127,
            operators: ["any"]
        },
        "Грузия": {
            id: 128,
            operators: ["any", "beeline", "geocell", "hamrah_e_aval", "magticom"]
        },
        "Греция": {
            id: 129,
            operators: ["any", "cosmote", "ose", "q_telecom", "vodafone", "wind"]
        },
        "Гвинея-Бисау": {
            id: 130,
            operators: ["any"]
        },
        "Гайана": {
            id: 131,
            operators: ["any"]
        },
        "Исландия": {
            id: 132,
            operators: ["any"]
        },
        "Коморы": {
            id: 133,
            operators: ["any"]
        },
        "Сент-Китс": {
            id: 134,
            operators: ["any"]
        },
        "Либерия": {
            id: 135,
            operators: ["any", "cellcom", "comium", "libercell", "libtelco", "lonestar"]
        },
        "Лесото": {
            id: 136,
            operators: ["any"]
        },
        "Малави": {
            id: 137,
            operators: ["any"]
        },
        "Намибия": {
            id: 138,
            operators: ["any"]
        },
        "Нигер": {
            id: 139,
            operators: ["any"]
        },
        "Руанда": {
            id: 140,
            operators: ["airtel", "any", "mtn"]
        },
        "Словакия": {
            id: 141,
            operators: ["any", "o2", "orange"]
        },
        "Суринам": {
            id: 142,
            operators: ["any"]
        },
        "Таджикистан": {
            id: 143,
            operators: ["any", "indigo", "megafon"]
        },
        "Монако": {
            id: 144,
            operators: ["any"]
        },
        "Бахрейн": {
            id: 145,
            operators: ["any"]
        },
        "Реюньон": {
            id: 146,
            operators: ["any"]
        },
        "Замбия": {
            id: 147,
            operators: ["airtel", "any", "mtn", "zamtel"]
        },
        "Армения": {
            id: 148,
            operators: ["any", "team", "viva", "vivo"]
        },
        "Сомали": {
            id: 149,
            operators: ["any"]
        },
        "Конго": {
            id: 150,
            operators: ["airtel", "any"]
        },
        "Чили": {
            id: 151,
            operators: ["any", "claro", "entel", "movistar", "vodafone", "wom"]
        },
        "Буркина-Фасо": {
            id: 152,
            operators: ["airtel", "any", "onatel", "telecel"]
        },
        "Ливан": {
            id: 153,
            operators: ["alfa", "any", "ogero", "touch"]
        },
        "Габон": {
            id: 154,
            operators: ["any"]
        },
        "Албания": {
            id: 155,
            operators: ["any", "telekom", "vodafone"]
        },
        "Уругвай": {
            id: 156,
            operators: ["antel", "any", "claro"]
        },
        "Маврикий": {
            id: 157,
            operators: ["any"]
        },
        "Бутан": {
            id: 158,
            operators: ["any"]
        },
        "Мальдивы": {
            id: 159,
            operators: ["any"]
        },
        "Гваделупа": {
            id: 160,
            operators: ["any"]
        },
        "Туркменистан": {
            id: 161,
            operators: ["any"]
        },
        "Французская Гвиана": {
            id: 162,
            operators: ["any"]
        },
        "Финляндия": {
            id: 163,
            operators: ["any", "dna", "elisa", "telia"]
        },
        "Сент-Люсия": {
            id: 164,
            operators: ["any"]
        },
        "Люксембург": {
            id: 165,
            operators: ["any", "tango", "tiptop"]
        },
        "Сент-Винсент и Гренадины": {
            id: 166,
            operators: ["any"]
        },
        "Экваториальная Гвинея": {
            id: 167,
            operators: ["any"]
        },
        "Джибути": {
            id: 168,
            operators: ["any"]
        },
        "Антигуа и Барбуда": {
            id: 169,
            operators: ["any"]
        },
        "Каймановы острова": {
            id: 170,
            operators: ["any"]
        },
        "Черногория": {
            id: 171,
            operators: ["any", "lebara", "lycamobile", "telenor"]
        },
        "Дания": {
            id: 172,
            operators: ["any", "lebara", "lycamobile", "telenor"]
        },
        "Швейцария": {
            id: 173,
            operators: ["any", "lebara"]
        },
        "Норвегия": {
            id: 174,
            operators: ["any", "lycamobile", "my_call", "telia"]
        },
        "Австралия": {
            id: 175,
            operators: ["any", "lebara", "optus", "telstra", "vodafone"]
        },
        "Эритрея": {
            id: 176,
            operators: ["any"]
        },
        "Южный Судан": {
            id: 177,
            operators: ["any", "mtn", "zain"]
        },
        "Сан-Томе и Принсипи": {
            id: 178,
            operators: ["any"]
        },
        "Аруба": {
            id: 179,
            operators: ["any"]
        },
        "Монтсеррат": {
            id: 180,
            operators: ["any"]
        },
        "Ангуилья": {
            id: 181,
            operators: ["any"]
        },
        "Северная Македония": {
            id: 183,
            operators: ["a1", "any", "lycamobile", "telekom", "vip"]
        },
        "Сейшельские Острова": {
            id: 184,
            operators: ["any"]
        },
        "Новая Каледония": {
            id: 185,
            operators: ["any"]
        },
        "Кабо-Верде": {
            id: 186,
            operators: ["any"]
        },
        "США Физический": {
            id: 187,
            operators: ["any", "at_t", "boost_mobile", "cricket_wireless", "h2o_wireless", "hello_mobile", "joltmobile", "lycamobile", "mint_mobile", "moabits", "physic", "textnow", "tmobile", "us_cellular", "verizon", "visible", "xfinity"]
        }
    }
}
