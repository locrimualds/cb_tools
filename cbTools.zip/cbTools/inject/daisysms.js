cbTools.sms.daisysms = {
    name: "DaisySMS",
    baseApiUrl: "https://daisysms.com/stubs/handler_api.php",
    apiKey: "",
    serviceCode: "re",
    country: "",
    countryName: "",
    operator: "",
    currency: "$",
    minBalance: 1,
    errorServerResponses: {
        "SERVER_UNAVAILABLE": "Сервер недоступен",
        "BAD_KEY": "Неверный API ключ",
        "WRONG_API_KEY": "Неверный API ключ",
        "API_KEY_NOT_VALID": "Неверный API ключ",
        "NO_NUMBERS": "Нет доступных номеров",
        "NO_BALANCE": "Недостаточно денег на балансе",
        "WRONG_SERVICE": "Неверный код сервиса Coinbase",
        "STATUS_CANCEL": "Номер закрыт",
        "NO_ACTIVATION": "Номер телефона не найден",
        "BAD_STATUS": "Невозможно обновить статус номера",
        "MAX_PRICE_EXCEEDED": "Максимальная цена превышена"
    },

    testConnect: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.daisysms.getApiURL({action: "getBalance"})})!
        const response = _result_function();
        _function_return(cbTools.sms.daisysms.returnResult(response, null, true));
    },

    getBalance: function() {
        _call_function(cbTools.request.get, {url: cbTools.sms.daisysms.getApiURL({action: "getBalance"})})!
        const response = _result_function();
        _function_return(cbTools.sms.daisysms.returnResult(response, 1));
    },

    getBalanceFormated: function(value) {
        return _number_format(value, 2, "", ".", " ") + this.currency;
    },

    getNumber: function() {
        const countryName = _function_argument("countryName");
        const operator = _function_argument("operator");
        const areas = _function_argument("areas");
        const maxPrice = _function_argument("maxPrice");

        _call_function(cbTools.request.get, {url: cbTools.sms.daisysms.getApiURL({action: "getNumber", service: cbTools.sms.daisysms.serviceCode, carriers: operator, areas: areas, max_price: maxPrice})})!
        const response = _result_function();
        const result = cbTools.sms.daisysms.returnResult(response, {id: 1, number: 2});

        if (!result.error && cbTools.countries.hasOwnProperty(countryName)) {
            result.data.number = result.data.number.slice(cbTools.countries[countryName].prefix.length);
        }

        _function_return(result);
    },

    getCode: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.daisysms.getApiURL({action: "getStatus", id: phoneNumber.id})})!
        const response = _result_function();
        if (response.indexOf("STATUS_WAIT") !== -1)
            _function_return(cbTools.sms.daisysms.returnResult(response, null, false));

        _function_return(cbTools.sms.daisysms.returnResult(response, 1));
    },

    cancelNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.daisysms.getApiURL({action: "setStatus", status: 8, id: phoneNumber.id})})!
    },

    completeNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.daisysms.getApiURL({action: "setStatus", status: 6, id: phoneNumber.id})})!
    },

    updateNumber: function() {
        const phoneNumber = _function_argument("phoneNumber");

        _call_function(cbTools.request.get, {url: cbTools.sms.daisysms.getApiURL({action: "setStatus", status: 3, id: phoneNumber.id})})!
        const response = _result_function();
        _function_return(cbTools.sms.daisysms.returnResult(response, response));
    },

    getApiURL: function (params) {
        var urlParams = [];
        for (var key in params) {
            if (Object.prototype.hasOwnProperty.call(params, key)) {
                urlParams[urlParams.length] = encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
            }
        }
        urlParams = urlParams.join('&');
        return this.baseApiUrl + "?api_key=" + this.apiKey + "&" + urlParams;
    },

    returnResult: function(result, reformatData, returnData) {
        if (cbTools.request.isError(cbTools.sms.daisysms.errorServerResponses, result))
            return cbTools.request.returnFormat(true, cbTools.sms.daisysms.errorServerResponses[result])

        if (returnData !== undefined)
            return cbTools.request.returnFormat(false, returnData);

        if (reformatData === null || reformatData === undefined)
            return cbTools.request.returnFormat(false, result);

        result = result.split(":");

        if (typeof reformatData === "number")
            return cbTools.request.returnFormat(false, result[reformatData]);

        for (var key in reformatData) {
            reformatData[key] = result[reformatData[key]]
        }

        return cbTools.request.returnFormat(false, reformatData);
    },

    getCountries: function () {
        _function_return(["США"]);
    },

    getOperators: function() {
        const country = _function_argument("country");
        _function_return(["any"]);
    },

    getCountryId: function() {
        const country = _function_argument("country");
        _function_return(country);
    },
}
